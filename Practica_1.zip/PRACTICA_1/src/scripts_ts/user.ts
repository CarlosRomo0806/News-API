interface UserData{
    email: string;
    password: string;
}

interface IUser{
    name: string;
    email: string;
    id?: number;  //metodos opcionales 
    password?: string;
    age?: number
}


class User implements IUser{ //Implementar es diferente que extender, cuando implementas, debes de tener todo lo que la interface contiene (como contrato) 
    name: string;
    email: string;
    id: number;
    password: string;
    age: number;


login(username: string, password: string): void{
    console.log('iniciando sesion')
}

logout(): void{

}

signup(data: any): void{
    return data;
}

findOne(id: number, options?:any){
    //Al final los parametros opcionales 
}

}

//Que es una interfaz? 
//Es la estructura/contrato que otra clase tomara


//Una clase abstracta es una clase que no esta diseñada para instanciarse, solo están hechas para heredarse

//Ejemplo de clase abstracta 
//Class Crud{
    //getAll()
    //getOne()
    //Create()
    //Update()
    //delete()
//}

//class Noticia extends Crud

//class Comentarios extends Crud