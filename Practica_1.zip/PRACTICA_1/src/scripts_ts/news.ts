declare let axios;

export class News{
    getAll(){
        const url: string = 'https://newsapi.org/v2/everything?q=bitcoin&apiKey=6bd902d1c00d43838642599002945c7e';
        return axios.get(url);
    }
}