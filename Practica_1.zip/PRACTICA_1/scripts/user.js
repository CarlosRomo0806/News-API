class User {
    login(username, password) {
        console.log('iniciando sesion');
    }
    logout() {
    }
    signup(data) {
        return data;
    }
    findOne(id, options) {
        //Al final los parametros opcionales 
    }
}
//Que es una interfaz? 
//Es la estructura/contrato que otra clase tomara
//Una clase abstracta es una clase que no esta diseñada para instanciarse, solo están hechas para heredarse
//Ejemplo de clase abstracta 
//Class Crud{
//getAll()
//getOne()
//Create()
//Update()
//delete()
//}
//class Noticia extends Crud
//class Comentarios extends Crud
