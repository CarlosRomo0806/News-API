export class Photo {
    getAll() {
        const url = 'https://jsonplaceholder.typicode.com/photos?albumId=1';
        return axios.get(url);
    }
}
